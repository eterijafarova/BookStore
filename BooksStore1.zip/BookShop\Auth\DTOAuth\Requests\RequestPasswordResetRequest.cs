namespace BookShop.Auth.DTOAuth.Requests
{
    public class RequestPasswordResetRequest
    {
        public string Email { get; set; }
    }

}