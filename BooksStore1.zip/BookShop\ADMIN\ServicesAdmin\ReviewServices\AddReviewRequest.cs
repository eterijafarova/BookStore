namespace BookShop.ADMIN.ServicesAdmin.ReviewServices;

public class AddReviewRequest
{
    public int Rating { get; set; }
    public string Comment { get; set; }
}
