namespace BookShop.Auth.DTOAuth.Requests;

public record ConfirmRequest(string username);