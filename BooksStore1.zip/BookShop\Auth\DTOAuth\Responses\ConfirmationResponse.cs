namespace BookShop.Auth.DTOAuth.Responses;

public class ConfirmationResponse
{
    public bool Success { get; set; }
    public string Message { get; set; }
}
