namespace BookShop.Auth.DTOAuth.Requests;

public record LoginRequest(string username, string password);